package com.example.project3;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.example.project3.R;
import com.example.project3.Event;

import org.w3c.dom.Text;

import java.util.List;

public class EventAdapter extends ArrayAdapter<Event> {

    public EventAdapter(@NonNull Context context, int resource, @NonNull List<Event> events) {
        super(context,resource,events);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View gridView = convertView;

        if(gridView == null) {
            gridView = LayoutInflater.from(getContext()).inflate(R.layout.event_list_item, parent, false);
        }

        // get views and set to the current object values
        TextView name = gridView.findViewById(R.id.textViewName);
        TextView date = gridView.findViewById(R.id.textViewDate);

        Event currentEvent = getItem(position);

        name.setText(currentEvent.getName());
        date.setText(currentEvent.getDate());

        return gridView;
    }
}