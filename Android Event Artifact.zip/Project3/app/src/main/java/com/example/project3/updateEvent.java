package com.example.project3;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.project3.R;
import com.example.project3.EventAdapter;
import com.example.project3.EventDBHelper;
import com.example.project3.Event;

public class updateEvent extends AppCompatActivity {
    TextView updateGreeting;
    EditText nameEditText, dateEditText;
    Button buttonOkay;

    EventDBHelper db;

    private EventAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        updateGreeting = findViewById(R.id.eventNameTextView);

        nameEditText = findViewById(R.id.eventNameEditText);
        dateEditText = findViewById(R.id.eventDateEditText);

        buttonOkay = findViewById(R.id.buttonAddOkay);

        db = EventDBHelper.getInstance(this);

        buttonOkay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String eventName = nameEditText.getText().toString();
                String eventDate = dateEditText.getText().toString();

                if(!eventName.isEmpty() && !eventDate.isEmpty()) {
                    Event event = new Event(eventName, eventDate);
                    db.update(event);
                    adapter.notifyDataSetChanged();
                    finish();
                }
                else {
                    Toast.makeText(updateEvent.this,"Enter value in each box.",Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}