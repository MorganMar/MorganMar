package com.example.project3;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.project3.R;

import java.util.Hashtable;

public class MainActivity extends AppCompatActivity {
    Button logButton, newButton;
    EditText userText, passText;
    Hashtable<String, String> userList = new Hashtable<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        logButton = findViewById(R.id.loginButton);
        newButton = findViewById(R.id.newUserButton);

        userText = findViewById(R.id.usernameBox);
        passText = findViewById(R.id.passwordBox);
    }
    public void loginLogic(View v) {
        String userString = userText.getText().toString();
        String passString = passText.getText().toString();
        Toast logToast = Toast.makeText(this,"User " + userString + " logged in.",Toast.LENGTH_SHORT);
        Toast passWrong = Toast.makeText(this,"Password for " + userString + " incorrect.",Toast.LENGTH_SHORT);
        Toast userWrong = Toast.makeText(this,"User " + userString + " not found.",Toast.LENGTH_SHORT);

        if (userList.containsKey(userString)) {
            if (passString.equals(userList.get(userString))) {
                logToast.show();
                goodLogin();
            }
            else {
                passWrong.show();
            }
        }
        else {
            userWrong.show();
        }
    }
    public void newUserLogic(View v) {
        String userString = userText.getText().toString();
        String passString = passText.getText().toString();
        Toast newUserToast = Toast.makeText(this,"New user " + userString + " registered, logging in.",Toast.LENGTH_SHORT);
        Toast alreadyToast = Toast.makeText(this,"User " + userString + " already exists.",Toast.LENGTH_SHORT);

        if (!userList.containsKey(userString)) {
            userList.put(userString, passString);
            newUserToast.show();
            goodLogin();

        } else {
            alreadyToast.show();
        }
    }
    // Method for valid user credentials
    private void goodLogin() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Grant SMS permission?");
        builder.setPositiveButton(R.string.okay_label, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int i) {
                dialog.dismiss();
                SmsManager sms = SmsManager.getDefault();
                Toast.makeText(MainActivity.this,"Sending message...",Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this, database.class);
                startActivity(intent);
            }
        });
        builder.setNegativeButton(R.string.cancel_label, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int i) {
                dialog.dismiss();
                Intent intent = new Intent(MainActivity.this, database.class);
                startActivity(intent);
            }
        });
        builder.show();

    }
}