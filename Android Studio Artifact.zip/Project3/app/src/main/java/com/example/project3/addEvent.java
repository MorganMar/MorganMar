package com.example.project3;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.content.Intent;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.project3.R;
import com.example.project3.EventAdapter;
import com.example.project3.EventDBHelper;
import com.example.project3.Event;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class addEvent extends AppCompatActivity {
    TextView newEventGreeting;
    EditText nameEditText, dateEditText;
    Button buttonOkay;
    EventDBHelper db;
    private EventAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        newEventGreeting = findViewById(R.id.eventNameTextView);

        nameEditText = findViewById(R.id.eventNameEditText);
        dateEditText = findViewById(R.id.eventDateEditText);

        buttonOkay = findViewById(R.id.buttonAddOkay);

        db = EventDBHelper.getInstance(this);

        buttonOkay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String eventName = nameEditText.getText().toString();
                String eventDate = dateEditText.getText().toString();

                Event event = new Event(eventName,eventDate);
                db.add(event);

                // Update layout
                adapter.notifyDataSetChanged();
                finish();

            }
        });

    }
}
